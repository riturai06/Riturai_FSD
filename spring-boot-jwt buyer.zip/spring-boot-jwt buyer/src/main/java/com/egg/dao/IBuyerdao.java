package com.egg.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.Buyer;






@Repository
public interface IBuyerdao extends JpaRepository<Buyer, Integer>{
	@Query(value = "FROM Buyer b WHERE b.buyerName=:bname")
	public Buyer findBuyerByName(@Param("bname") String buyerName);

}
