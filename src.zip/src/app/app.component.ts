import { Component } from '@angular/core';

import { AppointService } from './appointservice.service';
import { Appoint } from './Appoint';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'fitness';

  itemsmodel:Appoint[];
  items = new Appoint();
  constructor(private dataservice: AppointService)
  {

  }


 
    
   viewcome()
   {
     console.log("in view");
     this.dataservice.getAll().subscribe(itemsmodel=>this.itemsmodel=this.itemsmodel)
   }

   addcomp()
   {
     console.log( "DATA Inserted");
     this.items.id= 10;
     this.items.firstname="divya";
     this.items.lastname="rai";
     this.items.age=21;
     this.items.email="ritu@gmail.com";
     this.items.phonenumber=2556678;
     this.items.street="Rajiv Chowk";
     this.items.city="Bhilai";
     this.items.state="UP";
     this.items.country="India";
     this.items.pin=32435;
     this.items.trainerpreference="yes";
     this.items.physio=null;
     this.items.packagecost=1000;
     this.items.quote=50;

     this.dataservice.Insertdata(this.items).subscribe(itemsmodel=>this.itemsmodel=this.itemsmodel);
   }
}
