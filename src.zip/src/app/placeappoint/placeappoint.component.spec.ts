import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlaceappointComponent } from './placeappoint.component';

describe('PlaceappointComponent', () => {
  let component: PlaceappointComponent;
  let fixture: ComponentFixture<PlaceappointComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlaceappointComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlaceappointComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
