import { Component, OnInit } from '@angular/core';
import { AppRoutingModule } from '../app-routing.module';

import { AppointService } from '../appointservice.service';




@Component({
  selector: 'app-placeappoint',
  templateUrl: './placeappoint.component.html',
  styleUrls: ['./placeappoint.component.css']
})
export class PlaceappointComponent implements OnInit {

  appoint:AppointService;
  constructor(private placeappoint:AppointService) { }

  ngOnInit(): void {
  }

  createappointment()
  {
    this.placeappoint.Insertdata(this.appoint);
  }

}
