import { Component, OnInit } from '@angular/core';
import { AppointService } from '../appointservice.service';
import { Appoint } from '../appoint';


@Component({
  selector: 'app-viewappoint',
  templateUrl: './viewappoint.component.html',
  styleUrls: ['./viewappoint.component.css']
})
export class ViewappointComponent implements OnInit {
  apts:Appoint;
  constructor(private appointment:AppointService) { }

  ngOnInit(): void {
  }

  getaptdata()
  {
    this.appointment.getAll().subscribe(apts=>this.apts=apts);
  }

}
