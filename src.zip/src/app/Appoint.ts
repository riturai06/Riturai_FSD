export class Appoint
{

    id:number;
    firstname: string;
    lastname:string;
    age: number
    email:string;
    phonenumber:number;
    street:string;
    city:string;
    state:string;
    country:string;
    pin:number;
    trainerpreference:string;
    physio:boolean;
    slot:number;
    packagecost:number;
    quote:number;
}