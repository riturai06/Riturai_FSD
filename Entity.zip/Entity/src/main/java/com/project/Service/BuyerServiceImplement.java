package com.project.Service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Entity.Buyer;
import com.project.Repositories.IBuyerdao;

@Service
public class BuyerServiceImplement  implements IBuyerService {
    
	@Autowired
	private IBuyerdao buyerdao;

	public List<Buyer> getAllBuyer() {
		return buyerdao.findAll();
	}

	/*public Buyer getByBuyerName(String buyerName) {
		
		return dao.f;
	}*/

	public Integer createOrUpdate(Buyer buyer) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteById(Integer buyerId) {
		// TODO Auto-generated method stub
		
	}

	
	public Buyer createBuyer(Buyer buyer) {
		
		return buyerdao.save(buyer);
	}

	


	public Buyer updateBuyer(Buyer buyer) {
		Optional<Buyer> existingBuyer = buyerdao.findById(buyer.getBuyerId());
		Buyer newBuyer = null;
		if(existingBuyer.isPresent()) {
			newBuyer = existingBuyer.get();
			newBuyer.setBuyerName(buyer.getBuyerName());
			newBuyer.setPassword(buyer.getPassword());
			newBuyer.setEmail(buyer.getEmail());
			newBuyer.setMobileNo(buyer.getMobileNo());
			newBuyer = buyerdao.save(newBuyer);
		}
		
		return newBuyer;
	}

	public Optional<Buyer> getBuyerById(Integer buyerId) {
		return buyerdao.findById(buyerId);
	}

	@Override
	public Buyer getBuyerByName(String buyerName) {
		
		return buyerdao.findBuyerByName(buyerName);
	}

	

}
