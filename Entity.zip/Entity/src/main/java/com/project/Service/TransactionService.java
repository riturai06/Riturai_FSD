package com.project.Service;

import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public interface TransactionService {
	@Autowired
	private Transaction TransactionHistory;
	
	@Autowired IBuyerRepository buyer;
	
	public Optional<TransactionHistory> addTransaction(TransactionHistory transaction, Integer buyerId) {
		return buyer.findById(buyerId).map(buyer -> {
            transaction.setBuyer(buyer);
            return iTransactionHistory.save(transaction);
        });
	}
}
