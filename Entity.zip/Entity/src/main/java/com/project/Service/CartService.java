package com.project.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Entity.Buyer;
import com.project.Entity.Cart;
import com.project.Repositories.CartRepositories;
import com.project.Repositories.IBuyerdao;
@Service
public class CartService {

	@Autowired
	private CartRepositories cartdao;
	@Autowired
	private IBuyerdao buyerdao;
	
	public List<Cart> getAllCartItems(Integer buyerId) {
		
		return cartdao.findAll();
	}

	public Optional<Cart> addCartItem(Cart shoppingCartItem, Integer buyerId) {
		return buyerdao.findById(buyerId).map(buyer -> {
			shoppingCartItem.setBuyerId(buyer);
			return cartdao.save(shoppingCartItem);
		});
		
	}

	public String deleteCartItemById(Integer cartItemId) {
		cartdao.deleteById(cartItemId);
		return "Item with cartId"+cartItemId+" is deleted.";
	}

	public void deleteByBuyerId(Integer buyerId) {
	
		Optional<Buyer> buyer = buyerdao.findById(buyerId);
				cartdao.deleteByBuyerId(buyerId);
	}
}
