package com.project.Controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.project.Entity.Buyer;
import com.project.Repositories.IBuyerdao;
import com.project.Service.BuyerServiceImplement;

@RestController
@RequestMapping("/buyer")
public class BuyerRestController {
	
	@Autowired
	private BuyerServiceImplement buyerService;
	@Autowired
	private IBuyerdao dao;
	@GetMapping
	List<Buyer> getAllBuyer() {
		return buyerService.getAllBuyer();
	}
	
	@PostMapping(value="/create", produces = "application/json")
	public Buyer createBuyer(@RequestBody Buyer buyer) {
		return buyerService.createBuyer(buyer);
	}
	
	@PutMapping(value = "/update",produces = "application/json")
	public Buyer updateBuyer(@RequestBody Buyer buyer) {
		return buyerService.updateBuyer(buyer);
	}
	
	@GetMapping(value = "/getById/{bid}")
	public Optional<Buyer> getBuyerById(@PathVariable("bid") Integer buyer_id) {
		return buyerService.getBuyerById(buyer_id);
	}
	
	@GetMapping(value = "/getByName/{bname}")
	public Buyer getBuyerByName(@PathVariable("bname") String buyerName) {
		return buyerService.getBuyerByName(buyerName);
	}

}
