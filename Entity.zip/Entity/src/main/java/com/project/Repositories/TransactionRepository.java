package com.project.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Entity.Buyer;
import com.project.Entity.Transactions;

public interface TransactionRepository extends JpaRepository<Transactions, Integer>{

}
