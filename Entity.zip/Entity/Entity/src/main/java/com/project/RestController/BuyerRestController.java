package com.project.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.project.Entity.Buyer;
import com.project.Service.IBuyerService;

public class BuyerRestController {
	@Autowired
	private IBuyerService bservice;
	
	
	@RequestMapping("getAll")
	public List<Buyer> getAll(){
		
		return bservice.getAllBuyer();
	}
	
	@RequestMapping("getByName/{buyerName}")
	public Buyer getBuyerByName(@PathVariable("buyerName") String buyerName){
		
		return bservice.getByBuyerName(buyerName);
	}
	
//	@RequestMapping("getByNameAddr/{ename}/{addr}")
//	public Person getUsingNameAddress(@PathVariable("ename") String name, @PathVariable("addr") String ad) {
//		return service.findUsingNameAddress(name, ad);
//	}
	
	@RequestMapping(value = "/buyer", method = RequestMethod.POST, produces = "application/json")
	public Integer createOrUpdate (@RequestBody Buyer buyer) {
		
		return bservice.createOrUpdate(buyer);
	}
	
	@RequestMapping(value = "deleteById/{pid}", method = RequestMethod.DELETE)
	public void deleteById(@PathVariable("bid") Integer buyerId) {
		
		bservice.deleteById(buyerId);
	}
	
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public Buyer updateBuyer(@RequestBody Buyer buyer) {
		
		return bservice.update(buyer);
	}
	
	}
	
	

