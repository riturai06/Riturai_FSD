package com.project.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Seller {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int seller_id;
	@Column(name="user_name")
	private String username;
	
	private String password;
	@Column(name="company_name")
	private String companyname;
	private float GSTIN;
	@Column(name="brief_about_company")
	private String briefaboutcompany;
	@Column(name=" postal_address")
	private String postaladdress;
	private String website;
	private String emailid;
	private long contactnumber;
	
	

}
