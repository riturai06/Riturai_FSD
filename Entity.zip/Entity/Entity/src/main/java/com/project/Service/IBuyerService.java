package com.project.Service;

public interface IBuyerService {

}
