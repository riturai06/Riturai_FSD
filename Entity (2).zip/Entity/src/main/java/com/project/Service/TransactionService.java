package com.project.Service;

import javax.transaction.Transaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Entity.Transactions;

@Service
public interface TransactionService {
	/*@Autowired
	Transactions TransactionHistory;
	public Optional<TransactionHistory> addTransaction(TransactionHistory transaction, Integer buyerId) {
		return buyer.findById(buyerId).map(buyer -> {
            transaction.setBuyer(buyer);
            return iTransactionHistory.save(transaction);
        });
	}*/
}
