package com.project.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Entity.Buyer;
import com.project.Entity.Seller;
import com.project.Repositories.IBuyerdao;
import com.project.Repositories.ISellerdao;

@Service
public class ISellerService {
	
	@Autowired
	private ISellerdao sellerdao;


	public List<Seller> getAllSeller() {
		return sellerdao.findAll();
	}
	
	
	
}
