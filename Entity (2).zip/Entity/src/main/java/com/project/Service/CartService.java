package com.project.Service;

import java.util.List;
import java.util.Optional;

import org.hibernate.cache.spi.support.AbstractReadWriteAccess.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.project.Entity.Buyer;
import com.project.Entity.Cart;
import com.project.Entity.Items;
import com.project.Entity.PurchaseHistory;
import com.project.Entity.Transactions;
import com.project.Repositories.CartRepositories;
import com.project.Repositories.IBuyerdao;
import com.project.Repositories.ItemRepository;
import com.project.Repositories.PurchaseHistoryRepository;
import com.project.Repositories.TransactionRepository;
@Service
public class CartService {

	@Autowired
	private CartRepositories cartdao;
	@Autowired
	private IBuyerdao buyerdao;
	
	@Autowired
	private ItemRepository itemrepository;
	
	@Autowired
	private TransactionRepository transactionRepository;
	
	@Autowired
	private PurchaseHistoryRepository purchaseRepository;
	
	public List<Cart> getAllCartItems(Integer buyerId) {
		
		return cartdao.findAll();
	}

	public Optional<Cart> addCartItem(Cart shoppingCartItem, Integer buyerId) {
		return buyerdao.findById(buyerId).map(buyer -> {
			shoppingCartItem.setBuyerId(buyerId);
			return cartdao.save(shoppingCartItem);
		});
		
	}

	public String deleteCartItemById(Integer cartItemId) {
		cartdao.deleteById(cartItemId);
		return "Item with cartId"+cartItemId+" is deleted.";
	}

	public void deleteByBuyerId(Integer buyerId) {
	
		Optional<Buyer> buyer = buyerdao.findById(buyerId);
				cartdao.deleteById(buyerId);
	}
	
	public Cart updateCart(Cart cartItems,Integer cartItemId) {
		Cart newCart = null;
		Optional<Cart> cartItem = cartdao.findById(cartItemId);
		
		if(cartItem.isPresent()) {
		newCart = cartItem.get();
		newCart.setItemQty(cartItems.getItemQty());
		
		return cartdao.save(newCart);
		}
		
		return null;
		
	}
	
	
	public void checkoutCart(Integer buyerId)
	 {
		Double totalAmount = 0.00;
		Transactions transaction = null;
		PurchaseHistory purchaseHistory = null;
		Items cartItem = null;
		
		List<Cart> getAllCart = cartdao.getAllCartItems(buyerId);
		for(Cart cart : getAllCart) {
			Optional<Items> item = itemrepository.findById(cart.getCartItemId());
			totalAmount += item.get().getItemPrice();
		}
		Optional<Buyer> buyer  = buyerdao.findById(buyerId);
		transaction = new Transactions();
		transaction.setBuyerId(buyer.get());
		transaction.setTotalAmount(totalAmount);
		transaction.setTransactionType("Debited");
		transaction.setTransactionRemarks("PaymentDone");
		
		transactionRepository.save(transaction);
		 
		purchaseHistory = new PurchaseHistory();
		for(Cart cart : getAllCart) {
			purchaseHistory.setTransactionHistory(transaction);
			purchaseHistory.setItemId(cart.getCartItemId());
			purchaseHistory.setBuyerId(buyer.get());
			purchaseHistory.setPurchaseRemarks("purchased");
			purchaseHistory.setItemsQty(cart.getItemQty());
			 cartItem = new Items();
			 Optional<Items> newitem = itemrepository.findById(cart.getCartItemId());
			 cartItem = newitem.get();
			 int quantity = cartItem.getStock_number();
			 cartItem.setStock_number(quantity-cart.getItemQty());
			 itemrepository.save(cartItem);
			purchaseRepository.save(purchaseHistory);
		}
	}
	
	
	
}
