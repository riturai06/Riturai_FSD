package com.project.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Entity.Buyer;
import com.project.Entity.PurchaseHistory;

public interface PurchaseHistoryRepository extends JpaRepository<PurchaseHistory, Integer> {

}
