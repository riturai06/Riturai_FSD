package com.project.Repositories;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.project.Entity.Buyer;
import com.project.Entity.Cart;
@Repository
public interface CartRepositories extends JpaRepository<Cart, Integer>{

	@Transactional
	@Modifying
	@Query(value = "DELETE FROM cart_item WHERE cart_item.buyer_id_fk = :buyerId"
			,nativeQuery = true)
	public void emptyCart(@Param("buyerId")Integer buyerId);
	
	//public List<ShoppingCart> findAllByBuyerId(Integer buyerId);
	
	@Query(value = "SELECT * FROM cart_item cart WHERE cart.buyer_id_fk = :buyerId"
			,nativeQuery = true)
	public List<Cart> getAllCartItems(@Param("buyerId")Integer buyerId);
	

}
