package com.project.Controller;
import com.project.Entity.Cart;
import com.project.Repositories.CartRepositories;
import com.project.Repositories.IBuyerdao;
import com.project.Service.CartService;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.data.domain.Page;

import org.springframework.data.domain.Pageable;

import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;


@RestController

public class CartController {

 
   @Autowired
   
 private CartRepositories cartRepository;

   @Autowired
	private CartService cartService;
	
	@GetMapping(value = "/{bid}/getAll")
	public List<Cart> getAllCartItems(@PathVariable("bid") Integer buyer_id) {
		return cartService.getAllCartItems(buyer_id);
	}
	
	@PostMapping(value="/{bid}/addcartitem",produces = "application/json")
	public Cart addCartItem(@PathVariable("bid") Integer buyerId,@RequestBody Cart shoppingCartItem) {
		Optional<Cart> savedItem = cartService.addCartItem(shoppingCartItem, buyerId);
		return savedItem.get();
	}
	
	@DeleteMapping(value = "/{cartitem}/deletecartitembyid")
	public String deleteCartItem(@PathVariable("cartitem") Integer cartItemId) {
		return cartService.deleteCartItemById(cartItemId);
	}
	
	@DeleteMapping(value = "/{bid}/deleteall")
	public void deleteByBuyerId(@PathVariable("bid") Integer buyerId) {
		cartService.deleteByBuyerId(buyerId);
	}
	
	@PutMapping(value = "/{cartid}/update",produces = "application/json")
	public Cart updateCart(@RequestBody Cart cartItem,@PathVariable("cartid") Integer cartItemId) {
		return cartService.updateCart(cartItem, cartItemId);
	}
	

}
