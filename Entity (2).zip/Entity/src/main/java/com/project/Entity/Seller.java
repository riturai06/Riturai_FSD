package com.project.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Seller {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int seller_id;
	@Column(name="user_name")
	private String username;
	
	private String password;
	@Column(name="company_name")
	private String companyname;
	private float GSTIN;
	@Column(name="brief_about_company")
	private String briefaboutcompany;
	@Column(name=" postal_address")
	private String postaladdress;
	private String website;
	private String emailid;
	private long contactnumber;
	public int getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(int seller_id) {
		this.seller_id = seller_id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public float getGSTIN() {
		return GSTIN;
	}
	public void setGSTIN(float gSTIN) {
		GSTIN = gSTIN;
	}
	public String getBriefaboutcompany() {
		return briefaboutcompany;
	}
	public void setBriefaboutcompany(String briefaboutcompany) {
		this.briefaboutcompany = briefaboutcompany;
	}
	public String getPostaladdress() {
		return postaladdress;
	}
	public void setPostaladdress(String postaladdress) {
		this.postaladdress = postaladdress;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public long getContactnumber() {
		return contactnumber;
	}
	public void setContactnumber(long contactnumber) {
		this.contactnumber = contactnumber;
	}
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Seller(int seller_id, String username, String password, String companyname, float gSTIN,
			String briefaboutcompany, String postaladdress, String website, String emailid, long contactnumber) {
		super();
		this.seller_id = seller_id;
		this.username = username;
		this.password = password;
		this.companyname = companyname;
		GSTIN = gSTIN;
		this.briefaboutcompany = briefaboutcompany;
		this.postaladdress = postaladdress;
		this.website = website;
		this.emailid = emailid;
		this.contactnumber = contactnumber;
	}
	@Override
	public String toString() {
		return "Seller [seller_id=" + seller_id + ", username=" + username + ", password=" + password + ", companyname="
				+ companyname + ", GSTIN=" + GSTIN + ", briefaboutcompany=" + briefaboutcompany + ", postaladdress="
				+ postaladdress + ", website=" + website + ", emailid=" + emailid + ", contactnumber=" + contactnumber
				+ "]";
	}
	

}
