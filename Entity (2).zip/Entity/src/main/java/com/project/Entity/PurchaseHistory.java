package com.project.Entity;

    import java.time.LocalDate;

import javax.persistence.Column;
	import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.transaction.Transaction;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

import com.fasterxml.jackson.annotation.JsonFormat;

	/*Id
	Buyer_id
	Seller_id
	Transaction_id
	Item_id
	Number_of_items
	Date_time
	remarks*/
	@Entity
	@Table(name="purchase_history")

	public class PurchaseHistory {
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name = "purchase_id")
		private Long purchaseId;
		@ManyToOne
		@JoinColumn(name = "buyerid_fk")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private Buyer buyerId;
		@ManyToOne(fetch = FetchType.LAZY)
		@JoinColumn(name = "transactionhistory_fk")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private Transactions transactionHistory;
		@Column(name = "item_id")
		private Integer itemId;
		@Column
		private Integer ItemsQty;
		@JsonFormat(pattern = "dd/MM/yyyy")
		private LocalDate createdOn;
		@Column(name = "purchase_remarks")
		private String purchaseRemarks;
		public Long getPurchaseId() {
			return purchaseId;
		}
		public void setPurchaseId(Long purchaseId) {
			this.purchaseId = purchaseId;
		}
		public Buyer getBuyerId() {
			return buyerId;
		}
		public void setBuyerId(Buyer buyerId) {
			this.buyerId = buyerId;
		}
		public Transactions getTransactionHistory() {
			return transactionHistory;
		}
		public void setTransactionHistory(Transactions transaction) {
			this.transactionHistory = transaction;
		}
		public Integer getItemId() {
			return itemId;
		}
		public void setItemId(Integer itemId) {
			this.itemId = itemId;
		}
		public Integer getItemsQty() {
			return ItemsQty;
		}
		public void setItemsQty(Integer itemsQty) {
			ItemsQty = itemsQty;
		}
		public LocalDate getCreatedOn() {
			return createdOn;
		}
		public void setCreatedOn(LocalDate createdOn) {
			this.createdOn = createdOn;
		}
		public String getPurchaseRemarks() {
			return purchaseRemarks;
		}
		public void setPurchaseRemarks(String purchaseRemarks) {
			this.purchaseRemarks = purchaseRemarks;
		}
		public PurchaseHistory(Long purchaseId, com.project.Entity.Buyer buyerId, Transactions transactionHistory,
				Integer itemId, Integer itemsQty, LocalDate createdOn, String purchaseRemarks) {
			super();
			this.purchaseId = purchaseId;
			this.buyerId = buyerId;
			this.transactionHistory = transactionHistory;
			this.itemId = itemId;
			ItemsQty = itemsQty;
			this.createdOn = createdOn;
			this.purchaseRemarks = purchaseRemarks;
		}
		public PurchaseHistory() {
			// TODO Auto-generated constructor stub
		}
		@Override
		public String toString() {
			return "PurchaseHistory [purchaseId=" + purchaseId + ", buyerId=" + buyerId + ", transactionHistory="
					+ transactionHistory + ", itemId=" + itemId + ", ItemsQty=" + ItemsQty + ", createdOn=" + createdOn
					+ ", purchaseRemarks=" + purchaseRemarks + "]";
		}
		
		
		
	}















