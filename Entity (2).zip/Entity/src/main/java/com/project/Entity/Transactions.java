package com.project.Entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;


import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Transactions {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "transaction_id")
	private Long transactionId;
	@ManyToOne
	@JoinColumn(name = "buyerid_fk")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Buyer buyerId;
//	private enum transactionType {
//		DEBIT,CREDIT
//	}
	@Column(name="transaction_type")
	private String transactionType;
	@JsonFormat(pattern = "dd/MM/yyyy")
	private LocalDate date;
	@Column(name="transaction_remarks")
	private String transactionRemarks;
	
	@Column
	private Double totalAmount;
	//No arg Constructor
	public Transactions() {
		// TODO Auto-generated constructor stub
	}
	public Long getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(Long transactionId) {
		this.transactionId = transactionId;
	}
	public Buyer getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(Buyer buyerId) {
		this.buyerId = buyerId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public String getTransactionRemarks() {
		return transactionRemarks;
	}
	public void setTransactionRemarks(String transactionRemarks) {
		this.transactionRemarks = transactionRemarks;
	}
	public Double getTotalAmount() {
		return totalAmount;
	}
	public void setTotalAmount(Double totalAmount) {
		this.totalAmount = totalAmount;
	}
	public Transactions(Long transactionId, Buyer buyerId, String transactionType, LocalDate date,
			String transactionRemarks, Double totalAmount) {
		super();
		this.transactionId = transactionId;
		this.buyerId = buyerId;
		this.transactionType = transactionType;
		this.date = date;
		this.transactionRemarks = transactionRemarks;
		this.totalAmount = totalAmount;
	}
	@Override
	public String toString() {
		return "Transactions [transactionId=" + transactionId + ", buyerId=" + buyerId + ", transactionType="
				+ transactionType + ", date=" + date + ", transactionRemarks=" + transactionRemarks + ", totalAmount="
				+ totalAmount + "]";
	}

	
	
	
}
