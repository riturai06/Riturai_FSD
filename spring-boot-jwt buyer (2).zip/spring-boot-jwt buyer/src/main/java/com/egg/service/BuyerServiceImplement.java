package com.egg.service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.IBuyerdao;
import com.egg.model.Buyer;




@Service
public class BuyerServiceImplement  implements IBuyerService, UserDetailsService {
    
	@Autowired
	private IBuyerdao buyerdao;
	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public List<Buyer> getAllBuyer() {
		return buyerdao.findAll();
	}

	/*public Buyer getByBuyerName(String buyerName) {
		
		return dao.f;
	}*/

	public void deleteById(Integer buyerId) {
		// TODO Auto-generated method stub
		
	}

	
	public Buyer createBuyer(Buyer buyer) {
		buyer.setPassword( bcryptEncoder.encode(buyer.getPassword()));
		return buyerdao.save(buyer);
	}

	


	public Buyer updateBuyer(Integer buyer_Id, Buyer buyer) {
		Optional<Buyer> existingBuyer = buyerdao.findById(buyer.getBuyerId());
		Buyer newBuyer = null;
		if(existingBuyer.isPresent()) {
			newBuyer = existingBuyer.get();
			newBuyer.setBuyerName(buyer.getBuyerName());
			newBuyer.setPassword(buyer.getPassword());
			newBuyer.setEmail(buyer.getEmail());
			newBuyer.setMobileNo(buyer.getMobileNo());
			newBuyer = buyerdao.save(newBuyer);
		}
		
		return null;
	}

	public Optional<Buyer> getBuyerById(Integer buyerId) {
		return buyerdao.findById(buyerId);
	}

	@Override
	public Buyer getBuyerByName(String buyerName) {
		
		return buyerdao.findBuyerByName(buyerName);
	}
	public UserDetails loadUserByUsername(String buyerName) throws UsernameNotFoundException {
		Buyer buyer  = buyerdao.findBuyerByName(buyerName);
		if(buyer == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyer.getBuyerName(), buyer.getPassword(), getAuthority());
	}


	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_Buyer"));
	}


	public Buyer findOne(String buyerName) {
		return buyerdao.findBuyerByName(buyerName);
	}

	@Override
	public Buyer updateBuyer(Buyer buyer) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
