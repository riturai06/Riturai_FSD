package com.egg.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.egg.dao.IBuyerdao;
import com.egg.model.Buyer;
import com.egg.service.BuyerServiceImplement;


@RestController
@RequestMapping("/buyer")
public class BuyerRestController {
	
	@Autowired
	private BuyerServiceImplement buyerService;
	@Autowired
	private IBuyerdao dao;
	
	@GetMapping(value="/getAll")
	List<Buyer> getAllBuyer() {
		return buyerService.getAllBuyer();
	}
	
	@PostMapping(value="/create", produces = "application/json")
	public Buyer createBuyer(@RequestBody Buyer buyer) {
		return buyerService.createBuyer(buyer);
	}
	
	@PutMapping(value = "/update/{bid}",produces = "application/json")
	public Buyer updateBuyer(@PathVariable("bid") Integer buyer_id, @RequestBody Buyer buyer) {
		return buyerService.updateBuyer(buyer_id,buyer);
	}
	
	@GetMapping(value = "/getById/{bid}")
	public Optional<Buyer> getBuyerById(@PathVariable("bid") Integer buyer_id) {
		return buyerService.getBuyerById(buyer_id);
	}
	
	@GetMapping(value = "/getByName/{bname}")
	public Buyer getBuyerByName(@PathVariable("bname") String buyerName) {
		return buyerService.getBuyerByName(buyerName);
	}
	
	
}
