package com.project.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Entity.Buyer;



public interface IBuyerdao extends JpaRepository<Buyer, Integer>{

}
