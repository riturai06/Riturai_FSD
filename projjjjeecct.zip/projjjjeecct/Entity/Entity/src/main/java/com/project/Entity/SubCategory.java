package com.project.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
public class SubCategory {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int subcategory_id;
	@Column(name="subcategory_name")
	private String subcategoryname;
	
	@Column(name="brief_details")
	private int briefDetails;
	private float GST;
	@ManyToOne
	@JoinColumn(name="categoryId")
	private Category category_id;
	
	public SubCategory(int subcategory_id, String subcategoryname, int briefDetails, float gst) {
		super();
		this.subcategory_id = subcategory_id;
		this.subcategoryname = subcategoryname;
	    this.briefDetails = briefDetails;
		this.GST = gst;
	}
	
	
	@Override
	public String toString() {
		return "SubCategory [subcategory_id=" + subcategory_id + ", subcategoryname=" + subcategoryname
				+ ", briefDetails=" + briefDetails + ", GST=" + GST + ", category_id=" + category_id + "]";
	}


	public int getSubcategoryId() {
		return subcategory_id;
	}
	public void setSubcategory_id(int subcategory_id) {
		this.subcategory_id = subcategory_id;
	}
	public String getSubcategoryname() {
		return subcategoryname;
	}
	public void setSubcategoryname(String subcategoryname) {
		this.subcategoryname = subcategoryname;
	}
	
	public int getBriefDetails() {
		return briefDetails;
	}
	public void setBriefDetails(int briefDetails) {
		this.briefDetails = briefDetails;
	}
	public float getGST() {
		return GST;
	}
	public void setGST(float gst) {
		GST = gst;
	}
	
	

}
