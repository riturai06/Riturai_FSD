package com.project.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.web.bind.annotation.RequestBody;

import com.project.Entity.Buyer;

public interface IBuyerService {

	List<Buyer> getAllBuyer();

	

	

	void deleteById(Integer buyerId);

	
	 Buyer updateBuyer( Buyer buyer);
	Buyer createBuyer(Buyer buyer);

}
