package com.project.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.project.Entity.Cart;
@Service
public class CartService {

	public List<Cart> getAllCartItems(Integer buyerId) {
		// TODO Auto-generated method stub
		return null;
	}

	public Optional<Cart> addCartItem(Cart shoppingCartItem, Integer buyerId) {
		// TODO Auto-generated method stub
		return null;
	}

	public String deleteCartItemById(Integer cartItemId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteByBuyerId(Integer buyerId) {
		// TODO Auto-generated method stub
		
	}

}
