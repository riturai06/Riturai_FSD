package com.project.Entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.criteria.Fetch;

import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
@Table(name="Cart_Item")
public class Cart implements Serializable {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	@Column(name="cart_id")
	private int cartItemId;
	@Column(name="item_qty")
	private int itemQty;
	@Column(name="item_details")
	private String itemDetails;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name = "buyer_id_fk")
	@OnDelete(action = OnDeleteAction.CASCADE)
	private Buyer buyer_id;
	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	public int getItemQty() {
		return itemQty;
	}
	public void setItemQty(int itemQty) {
		this.itemQty = itemQty;
	}
	public String getItemDetails() {
		return itemDetails;
	}
	public void setItemDetails(String itemDetails) {
		this.itemDetails = itemDetails;
	}
	@Override
	public String toString() {
		return "Cart [cartItemId=" + cartItemId + ", itemQty=" + itemQty + ", itemDetails=" + itemDetails + "]";
	}
	public Cart(int cartItemId, int itemQty, String itemDetails) {
		super();
		this.cartItemId = cartItemId;
		this.itemQty = itemQty;
		this.itemDetails = itemDetails;
	}
	
	public Cart() {
		
	}
	
	

}
