package com.project.Repositories;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Entity.Buyer;
import com.project.Entity.Cart;

public interface CartRepositories extends JpaRepository<Cart, Integer>{

	
}
