package com.project.Repositories;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.Entity.Buyer;


@Transactional
@Repository
public interface IBuyerdao extends JpaRepository<Buyer, Integer>{

}
