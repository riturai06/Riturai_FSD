package com.cts.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class Name {
	private String salutation;
	@Column(name="fname")
	private String firstName;
	@Column(name="lname")
	private String lastName;
	public Name() {
		// TODO Auto-generated constructor stub
	}
	public Name(String salutation, String firstName, String lastName) {
		super();
		this.salutation = salutation;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	public String getSalutation() {
		return salutation;
	}
	public void setSalutation(String salutation) {
		this.salutation = salutation;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
}
