package com.cts.hibernate.HibernateEmbedded;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.hibernate.model.Buy;
import com.cts.hibernate.model.Name;
import com.cts.hibernate.model.Supply;

public class App 
{
    public static void main( String[] args )
    {
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();
        Session session = sessionFactory.openSession();
        Name Name1 = new Name("Ms.","Jyoti", "Singh");
        Name Name2 = new Name("Mrs.","Shweta", "Tiwari"); 
        Name Name3 = new Name("Mr.","Soorya", "Sharma"); 
        Supply supplier = new Supply(Name1);
        Buy buyer =  new Buy(Name2);
        Buy buyer1 =  new Buy(Name3);
        session.beginTransaction();
        session.save(supplier);
        session.save(buyer);
        session.save(buyer1);
        session.getTransaction().commit();
        session.close();
    }
}
