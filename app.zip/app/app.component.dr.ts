import { Directive, ElementRef, Renderer2, AfterViewInit,HostListener } from '@angular/core';

@Directive({ 
     selector: '[cpDefaultTheme]' 
})
export class CPDefaultThemeDirective implements AfterViewInit {
    [x: string]: any;
    constructor(private renderer: Renderer2, private elRef: ElementRef) {
    }

    ngAfterViewInit(): void {
       this.elRef.nativeElement.style.color = 'blue';
       this.elRef.nativeElement.style.fontSize = '20px';
    }		


// Event listeners for element hosting
  // the directive
    @HostListener('mouseenter') onMouseEnter() {
        this.hover(true);
    }

    @HostListener('mouseleave') onMouseLeave() {
        this.hover(false);
    }
  // Event method to be called on mouse enter and on mouse leave
    hover(shouldUnderline: boolean){
        if(shouldUnderline){
        // Mouse enter   
this.renderer2.setElementStyle(this.elRef.nativeElement, 'text-decoration', 'underline');
        } else {
    // Mouse leave           
this.renderer2.setElementStyle(this.elRef.nativeElement, 'text-decoration', 'none');
        }
    }

} 