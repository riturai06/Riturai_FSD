import { Component } from '@angular/core';

@Component({
  selector: 'app-stopwatch',
  template: '<h2>{{counter}}</h2>'
})
export class StopwatchComponent {
	shouldRun:boolean = false;
	counter:number = 0;
	count:number=1000;
	interval:any;
	start() {
	      this.shouldRun = true;
		  this.interval = setInterval(() =>
  	      {  
			if(this.shouldRun === false){
			   clearInterval(this.interval);
			}
		    this.counter = this.counter + 1;			
	      }, this.count);
	}
	stop() {
	   this.shouldRun = false;
	}

	restart() {
		
		
		
        this.counter=0;
		this.shouldRun = true;
		
		let interval = setInterval(() =>
		  {  
		  if(this.shouldRun === false){
			 clearInterval(this.interval);
		  }
		  this.counter = this.counter + 1;			
		}, this.count);
  }

  fast()
  {
	  this.stop();
	  clearInterval(this.interval);
	  this.count-=1000;
	  this.start();
  }

  slow()
  {   clearInterval(this.interval);
	 
	
	  this.count+=1000;
	  this.start();
  }
	
}    